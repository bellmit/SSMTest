create view PF_ORGAN as
select "ORGAN_ID","ORGAN_NAME","REGION_CODE","CREATE_DATE","EMAIL","OFFICE_TEL","SUPER_ORGAN_ID","REMARK","ORGAN_NO" from bdcdj_platform.PF_ORGAN@bdcdj_platform
/

