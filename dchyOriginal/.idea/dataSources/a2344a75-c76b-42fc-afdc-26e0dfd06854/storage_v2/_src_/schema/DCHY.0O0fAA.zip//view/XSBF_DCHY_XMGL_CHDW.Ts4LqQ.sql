create view XSBF_DCHY_XMGL_CHDW as
select "CHDWID","CHDWMC","TYSHXYDM","FRDB","ZZDJ","DWDZ","LXR","LXDH","LRSJ","LRR","BGDZS","BGDZSS","BGDZQX","BGDZXX" from dchyxsbf.dchy_xmgl_chdw
/

