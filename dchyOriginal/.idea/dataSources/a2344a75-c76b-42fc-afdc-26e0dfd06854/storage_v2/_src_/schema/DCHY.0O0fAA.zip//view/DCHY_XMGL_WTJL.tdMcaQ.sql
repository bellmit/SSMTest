create view DCHY_XMGL_WTJL as
select "CHXMID","XQFBBH","CHGCBH","GCMC","JSDWMC","CHDWMC","CHJD","WTSJ","WTZT",gcdzqx,GCDZSS from (select distinct chxm1.chxmid,
        chxm1.xqfbbh,
        chxm1.chgcbh,
        chgc1.gcmc,
        chgc1.wtdw AS JSDWMC,
        chgc1.gcdzqx,
        chgc1.gcdzss,
        chdwxx1.chdwmc,
        clsx.mc AS CHJD,
        chxm1.fbsj AS wtsj,
        case
        when chxm1.wtzt = '2' then
        '待接受'
        WHEN chxm1.wtzt = '3' then
        '已接受'
        end as wtzt
        from dchy_xmgl_chxm chxm1
        left join dchy_xmgl_chgc chgc1
        on chgc1.chgcid = chxm1.chgcid
        left join dchy_xmgl_chxm_chdwxx chdwxx1
        on chdwxx1.chxmid = chxm1.chxmid
        left join (select distinct cl.chxmid, fdm.mc
        from dchy_Xmgl_chxm_clsx cl
        left join dchy_xmgl_zd zd
        on zd.dm = cl.clsx
        and zd.zdlx = 'CLSX'
        left join dchy_xmgl_zd fdm
        on fdm.dm = zd.fdm
        and fdm.zdlx = 'CLSX'
        where fdm.mc is not null) clsx
        on clsx.chxmid = chxm1.chxmid
        where
             chxm1.fbsj IS NOT NULL and chxm1.wtzt in ('2', '3')
        union all
        select distinct chxm2.chxmid,
        chxm2.xqfbbh,
        chxm2.chgcbh,
        chgc2.gcmc,
        chgc2.wtdw,
        chgc2.gcdzqx,
        chgc2.gcdzss,
        chdwxx2.chdwmc,
        clsx.mc AS CHJD,
       chxm2.slsj AS wtsj,
        case
        when chxm2.xmzt = '2' then
        '已备案'
        WHEN chxm2.xmzt = '99' then
        '已办结'
        end as wtzt
        from xsbf_dchy_xmgl_chxm chxm2
        left join xsbf_dchy_xmgl_chgc chgc2
        on chgc2.chgcid = chxm2.chgcid
        left join xsbf_dchy_xmgl_chxm_chdwxx chdwxx2
        on chdwxx2.chxmid = chxm2.chxmid
        left join (select distinct cl.chxmid, fdm.mc
        from xsbf_dchy_Xmgl_chxm_clsx cl
        left join dchy_xmgl_zd zd
        on zd.dm = cl.clsx
        and zd.zdlx = 'CLSX'
        left join dchy_xmgl_zd fdm
        on fdm.dm = zd.fdm
        and fdm.zdlx = 'CLSX'
        where fdm.mc is not null) clsx
        on clsx.chxmid = chxm2.chxmid
        where
             chxm2.slsj IS NOT NULL and chxm2.xmzt in ('2', '99')) t
        where t.chjd is not null
        order by t.wtsj desc
/

