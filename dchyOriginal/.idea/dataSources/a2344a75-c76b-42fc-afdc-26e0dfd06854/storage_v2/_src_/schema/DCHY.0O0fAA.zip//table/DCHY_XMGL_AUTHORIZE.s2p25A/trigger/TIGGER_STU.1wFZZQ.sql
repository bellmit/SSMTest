create trigger TIGGER_STU
    before insert
    on DCHY_XMGL_AUTHORIZE
    for each row
    when (NEW.ID IS NULL)
BEGIN
    SELECT SEQ_STU.NEXTVAL INTO:NEW.ID FROM DUAL;
END;
/

