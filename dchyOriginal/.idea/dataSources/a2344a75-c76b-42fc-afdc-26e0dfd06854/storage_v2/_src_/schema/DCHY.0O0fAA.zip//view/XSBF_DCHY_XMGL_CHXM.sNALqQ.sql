create view XSBF_DCHY_XMGL_CHXM as
select "CHXMID","CHZSX","QJFS","YYQJSJ","QJDD","SJR","SLSJ","XMZT","PJZT","CHGCID","CHGCBH","XMLY","SLBH","FBSJ","FBR","CLRZGYQ","WJZXID","CGFS","CGJFRQ","XQFBBH","SJDD","SJRLXDH","WTZT" from dchyxsbf.dchy_xmgl_chxm
/

